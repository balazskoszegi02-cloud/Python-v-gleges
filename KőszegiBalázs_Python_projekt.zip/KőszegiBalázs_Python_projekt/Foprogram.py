from Edzesterv_adatkezeles import edzesnaplo # A másik fájlból importálja az edzesnapló classt

def menu(): #felhasználói felület
    print("="*30)
    print("      EDZÉSTERV NAPLÓ")
    print("="*30)
    print("1. Új edzés rögzítése")
    print("2. Napló megtekintése")
    print("3. Kilépés")
    print("-" * 30)

def foprogram():
    naplo=edzesnaplo() #a másik fájlból importált classt-t használja

    while True: #kilépésig megy
        menu() #menu kiírása
        valasztas=input("Válassz a menüpontok közül (1-3): ") #almenü választó

        if valasztas == '1':
            print("Új edzés")
            gyakorlat=input('Válassz egy gyakorlatot: ')
            ismetles=input('Hány ismátlést csináltál? ')
            

            while True: #hibavédelem: A súly csak szám lehet. Ezt ellenőrzi le
                suly=input('Mekkora súlyt használtál? [kg] ')
                try:
                    suly=float(suly)
                    break
                except ValueError:
                    print('Rossz input, számot adj meg')
            if naplo.edzes_mentese(gyakorlat, ismetles, suly)==True:
                print("Sikeres mentés") #az edés mentése függvénynek adjuk az adatot
        elif valasztas == '2':
            print(naplo.olvasas()) #olvasas függvénnyel kiíratjuk az edzéseket
        elif valasztas == '3':
            break #megszakítja a fő while true ciklust, így a program leáll
        else: # ha rosszul választ a felhasználó
            print('1-től 3-ig válassz')

foprogram() #foprogram elindul