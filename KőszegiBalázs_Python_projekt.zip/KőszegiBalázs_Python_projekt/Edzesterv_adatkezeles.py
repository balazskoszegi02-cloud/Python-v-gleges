import datetime #dátumhoz
import os #fájlkezeléshez


#Edzésnapló adatkezeléséhez osztály létrehozása
class edzesnaplo:
    def __init__(self, fajlnev="edzesnaploKBprojekt.txt"): #új naplót hoz létre
        self.fajlnev=fajlnev

    def edzes_mentese(self,gyakorlat,ismetles,suly): #új ezdések rögzítése fájlba. 
        datum=datetime.datetime.now().strftime("%Y.%m.%d.") #jelenlegi dátum lekérése
        try:
            with open(self.fajlnev,"a", encoding="utf-8") as f:
                f.write(f"Dátum: {datum}; Gyakorlat: {gyakorlat}; Ismétlés: {ismetles}; Súly: {suly}\n")
            return True    #hozzáfűzés módban megnyitja a fájlt, beírja a dátumot adatokat, utána bezárja. Ha siker: true érték
        except Exception as error: #Ha a try nem sikerül: hibaüzenetet kiírja és értéket false-ra állítja
            print(f"Hiba:{error}")
            return False
        
    def olvasas(self):
        if not os.path.exists(self.fajlnev): #van-e már fájl
            return('Nincs mentésed')
        try:
            with open(self.fajlnev, 'r',encoding="utf-8") as f:
                return f.read() #beolvassa a fájlt
        except Exception as error: # Ha nem sikerül a beolvasás
            return f"Hiba:{error}"